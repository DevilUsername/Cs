﻿namespace apipi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_A = new System.Windows.Forms.TextBox();
            this.txt_B = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_H1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_H2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_D1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_D2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_D3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_Part = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Gen_Part = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "A";
            // 
            // txt_A
            // 
            this.txt_A.Location = new System.Drawing.Point(64, 31);
            this.txt_A.Name = "txt_A";
            this.txt_A.Size = new System.Drawing.Size(128, 22);
            this.txt_A.TabIndex = 2;
            // 
            // txt_B
            // 
            this.txt_B.Location = new System.Drawing.Point(64, 59);
            this.txt_B.Name = "txt_B";
            this.txt_B.Size = new System.Drawing.Size(128, 22);
            this.txt_B.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "B";
            // 
            // txt_H1
            // 
            this.txt_H1.Location = new System.Drawing.Point(64, 87);
            this.txt_H1.Name = "txt_H1";
            this.txt_H1.Size = new System.Drawing.Size(128, 22);
            this.txt_H1.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "H1";
            // 
            // txt_H2
            // 
            this.txt_H2.Location = new System.Drawing.Point(64, 115);
            this.txt_H2.Name = "txt_H2";
            this.txt_H2.Size = new System.Drawing.Size(128, 22);
            this.txt_H2.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "H2";
            // 
            // txt_D1
            // 
            this.txt_D1.Location = new System.Drawing.Point(64, 143);
            this.txt_D1.Name = "txt_D1";
            this.txt_D1.Size = new System.Drawing.Size(128, 22);
            this.txt_D1.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "D1";
            // 
            // txt_D2
            // 
            this.txt_D2.Location = new System.Drawing.Point(64, 171);
            this.txt_D2.Name = "txt_D2";
            this.txt_D2.Size = new System.Drawing.Size(128, 22);
            this.txt_D2.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "D2";
            // 
            // txt_D3
            // 
            this.txt_D3.Location = new System.Drawing.Point(64, 199);
            this.txt_D3.Name = "txt_D3";
            this.txt_D3.Size = new System.Drawing.Size(128, 22);
            this.txt_D3.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 199);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "D3";
            // 
            // txt_Part
            // 
            this.txt_Part.Location = new System.Drawing.Point(521, 534);
            this.txt_Part.Name = "txt_Part";
            this.txt_Part.Size = new System.Drawing.Size(100, 22);
            this.txt_Part.TabIndex = 15;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(616, 534);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 22);
            this.textBox9.TabIndex = 16;
            this.textBox9.Text = ".sldprt";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(444, 537);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "Part Name";
            // 
            // Gen_Part
            // 
            this.Gen_Part.Location = new System.Drawing.Point(16, 266);
            this.Gen_Part.Name = "Gen_Part";
            this.Gen_Part.Size = new System.Drawing.Size(186, 185);
            this.Gen_Part.TabIndex = 18;
            this.Gen_Part.Text = "Generate Part";
            this.Gen_Part.UseVisualStyleBackColor = true;
            this.Gen_Part.Click += new System.EventHandler(this.Gen_Part_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::apipi.Properties.Resources.Drawing1;
            this.pictureBox1.Location = new System.Drawing.Point(244, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(798, 470);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1054, 617);
            this.Controls.Add(this.Gen_Part);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.txt_Part);
            this.Controls.Add(this.txt_D3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_D2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_D1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_H2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_H1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_B);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_A);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_A;
        private System.Windows.Forms.TextBox txt_B;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_H1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_H2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_D1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_D2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_D3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_Part;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button Gen_Part;
    }
}


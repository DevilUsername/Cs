﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace apipi
{
    internal class GetSolidworks
    {
        private static SldWorks SwApp;
        public GetSolidworks()
        {

        }

        internal static SldWorks GetApplication()
        {
            if (SwApp == null)
            {
                SwApp = Activator.CreateInstance(Type.GetTypeFromProgID("sldWorks.Application")) as SldWorks;
                SwApp.Visible = true;
                return SwApp;
            }
            return SwApp;

        }
    }
}
